export interface iCar {
  horsepower: number;
  model: string;
  price: number;
  year: number;
  id: number;
}
