import { iCar } from "./iCar";

export interface iCars {
  make: string;
  value: iCar;
}
