import carsJSON from "../../cars.json";
import { Acura } from "../Acura/Acura";
import { AstonMartin } from "../Aston-martin/Aston";
import { Audi } from "../Audi/Audi";
import { Bmw } from "../BMW/Bmw";
import { Car } from "../Car";
import { iCars } from "../Interfaces/iCars";

export class Render {
  cars: Car[] = [];

  display() {
    carsJSON.forEach((car) => this.createCandy(car as iCars));
    for (let car of this.cars) {
      console.log(car.toString(), car.carHistory());
    }
  }

  createCandy(data: iCars) {
    let car: Car;
    if (data.value.year !== 2015) return;
    switch (data.make) {
      case "bmw":
        car = new Bmw(
          data.value.model,
          data.value.horsepower,
          data.value.price,
          data.make
        );
        break;
      case "acura":
        car = new Acura(
          data.value.model,
          data.value.horsepower,
          data.value.price,
          data.make
        );
        break;
      case "aston-martin":
        car = new AstonMartin(
          data.value.model,
          data.value.horsepower,
          data.value.price,
          data.make
        );
        break;
      case "audi":
        car = new Audi(
          data.value.model,
          data.value.horsepower,
          data.value.price,
          data.make
        );
        break;

      default:
        throw new Error("There is not such a car");
    }
    this.cars.push(car);
  }
}
