export abstract class Car {
  private _model: string;
  private _horsepower: number;
  private _price: number;
  private _mark: string;
  constructor(model: string, horsepower: number, price: number, mark: string) {
    this._mark = mark;
    this._model = model;
    this._horsepower = horsepower;
    this._price = price;
  }

  toString(): string {
    return `Marka: ${this._mark}, model: ${this._model}, cena: ${this._price}, konie mechaniczne: ${this._horsepower}`;
  }
  carHistory(): string {
    throw new Error ( "Metod not implemented");
  }
}
