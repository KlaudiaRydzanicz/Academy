export enum eHistoryCar{
  new = "Jestem prosto z fabryki",
  afterleasing = "Już mnie testowali przez 2 lata",
  secondowner = "Weź mnie mam tylko 30 tys przebiegu",
}
