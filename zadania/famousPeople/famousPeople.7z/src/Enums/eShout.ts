export enum eShout {
  writers = "Create Literature",
  mathematicians = "Solves equations",
  generals = "Plans strategies",
}
