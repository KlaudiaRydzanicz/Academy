export enum eGender {
  man = "Man",
  woman = "Woman",
  another = "SuperWoman/Man",
}
