export interface iArtefact {
  artefact: string;
}
