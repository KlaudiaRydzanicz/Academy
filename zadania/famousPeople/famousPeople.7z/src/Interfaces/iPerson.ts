export interface iPerson {
  name: string;
  domain: string;
  nationality: string;
}
