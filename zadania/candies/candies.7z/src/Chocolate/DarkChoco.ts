import { Chocolate } from "./Chocolate";

export class DarkChoco extends Chocolate {
  constructor(name: string, precents: number) {
    super(name, precents);
  }
}
