import { Chocolate } from "./Chocolate";

export class MilkChoco extends Chocolate {
  constructor(name: string, precents: number) {
    super(name, precents);
  }
}
