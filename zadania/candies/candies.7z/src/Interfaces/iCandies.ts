import { iCandy } from "./iCandy";

export interface iCandies {
  class: string;
  value: iCandy;
}
