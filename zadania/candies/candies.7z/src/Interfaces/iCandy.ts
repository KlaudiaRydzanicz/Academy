export interface iCandy {
  name: string;
  percents: number;
}
