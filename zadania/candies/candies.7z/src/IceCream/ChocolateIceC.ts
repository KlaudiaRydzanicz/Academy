import { IceCream } from "./IceCream";

export class ChocolateIceC extends IceCream {
  constructor(name: string, precents: number) {
    super(name, precents);
  }
}
