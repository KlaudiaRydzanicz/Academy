import { IceCream } from "./IceCream";

export class Nutella extends IceCream {
  constructor(name: string, precents: number) {
    super(name, precents);
  }
 
}
