export enum eHowToMakes {
  melting = "Melting cacao mas and add: butter, milk and sugar",
  baking = "Prepare ingredients, mix and bake",
  freezing = "Prepare ingredients, mix and freeze",
}
