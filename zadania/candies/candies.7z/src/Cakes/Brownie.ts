import { Cakes } from "./Cakes";

export class Brownie extends Cakes {
  constructor(name: string, precents: number) {
    super(name, precents);
  }
}
