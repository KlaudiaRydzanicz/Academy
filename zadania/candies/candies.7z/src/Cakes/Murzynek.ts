import { Cakes } from "./Cakes";

export class Murzynek extends Cakes {
  constructor(name: string, precents: number) {
    super(name, precents);
  }

}
