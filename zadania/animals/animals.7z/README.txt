W pliku AnimalsJSON znajdują się przykładowe zwierzęta z różnych gatunków. Wyświetl te zwierzęta w zależności od gatunku.
W consoli powinny pojawić się informacje o gatunku, nazwie, ilości nóg, odgłosie jakie wydaje zwierzę.
 Każdy Gatunek ma różny stopień zagrożenia dla człowieka:
 firtsLevel = "przyjazne",
  secondLevel = "dzikie",
  thirdLevel = "niebezpieczne",
  Możesz samemu dopasowac poziom do gatunku. 
  Dodatkowo gatunki powiązane są z typem prtzemieszczania się zwierząt:
  lądowe = "lądowe",
  wodne = "Wodne",
  latajace = "Latające",

  te informacje równiez powinny się wyświetlać przy każdym zwierzaku :)
  