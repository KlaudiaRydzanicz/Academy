import { Animal } from "../Animal";
import { eDangerous } from "../Enums/eDangerous";

export class Ptaki extends Animal {
  static voices: Set<string> = new Set<string>();

  howDangerous(): string {
    return `Poziom zagrożenia dla człowieka : ${eDangerous.firtsLevel}`;
  };
  static getVoices(): string[] {
    return Array.from(this.voices);
  }
}
