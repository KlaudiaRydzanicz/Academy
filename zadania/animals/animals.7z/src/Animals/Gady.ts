import { Animal } from "../Animal";
import { eDangerous } from "../Enums/eDangerous";

export class Gady extends Animal {
  static voices: Set<string> = new Set<string>();


  howDangerous(): string {
    return `Poziom zagrożenia dla człowieka : ${eDangerous.thirdLevel}`;
  }
  static getVoices(): string[] {
    return Array.from(this.voices);
  }
}
