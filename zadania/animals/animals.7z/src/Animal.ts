export abstract class Animal {
  gatunek: string;
  nazwa: string;
  nogi: number;
  odglosy: string;
  typ: string;

  constructor(gatunek: string, nazwa: string, nogi: number, odglosy: string, typ: string) {
    this.gatunek = gatunek;
    this.nazwa = nazwa;
    this.nogi = nogi;
    this.odglosy = odglosy;
    this.typ = typ;
  }
  toString(): string {
    return `Gatunek: ${this.gatunek}, nazwa : ${this.nazwa}, liczba nóg: ${this.nogi}, wydawane odgłosy: ${this.odglosy}, ${this.typ}`;
  }
  howDangerous(): string {
    throw new Error ("Method howDangerous not implemented");
  }
static getVoices(): string[]{
  throw new Error ("Method getVoices not implemented");
}
}
