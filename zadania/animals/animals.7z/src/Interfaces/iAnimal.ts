export interface iAnimal {
  nazwa: string;
  nogi: number;
  odglosy: string;
}
