import { iAnimal } from "./iAnimal";

export interface iAnimals {
  gatunek: string;
  value: iAnimal;
}
