export enum eDangerous {
  firtsLevel = "przyjazne",
  secondLevel = "dzikie",
  thirdLevel = "niebezpieczne",
}
