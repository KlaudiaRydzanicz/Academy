export enum eType {
  lądowe = "lądowe",
  wodne = "Wodne",
  latajace = "Latające",
  dzikie = "dzikie",
}
