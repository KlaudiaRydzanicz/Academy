import { Render } from "./Render/Render";

(function () {
  const render = new Render();
  render.display();
})();
