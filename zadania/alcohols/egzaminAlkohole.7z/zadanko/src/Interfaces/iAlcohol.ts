export interface iAlcohol {
  name: string;
  percents: number;
}
