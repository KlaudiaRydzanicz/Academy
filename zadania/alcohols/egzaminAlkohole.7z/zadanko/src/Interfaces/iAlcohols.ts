import { iAlcohol } from "./iAlcohol";

export interface iAlcohols {
  class: string;
  value: iAlcohol;
}
