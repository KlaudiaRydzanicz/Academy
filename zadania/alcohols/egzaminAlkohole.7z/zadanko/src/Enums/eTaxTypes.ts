export enum eTaxTypes {
  firtsLevel = "First level",
  secondLevel = "Second level",
  thirdLevel = "Third Level",
}
