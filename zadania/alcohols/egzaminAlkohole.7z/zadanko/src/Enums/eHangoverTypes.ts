export enum eHangover {
  amnesia = "Amnesia",
  massiveHeadahe = "Massive Headahe",
  helicopterEffect = "Helicopter Effect",
  grassIsGrowingToLoud = "Grass is growing to loud!!!",
}
